using System;

namespace Data_M2;

// TASK 5: Create Transaction Class
// Purpose: Represent deposits, withdrawals, and transfers.

public class Transaction
{
    // TASK 5: Step 1 - Add properties for transaction details
    // Placeholder for adding properties to represent transaction details

    // TASK 5: Step 2 - Add a constructor to initialize transaction details
    // Placeholder for adding a constructor to initialize the transaction
}