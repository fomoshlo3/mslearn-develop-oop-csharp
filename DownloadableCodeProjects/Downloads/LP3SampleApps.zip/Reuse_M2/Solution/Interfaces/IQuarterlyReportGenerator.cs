using System;

namespace Reuse_M2;

public interface IQuarterlyReportGenerator
{
    void GenerateQuarterlyReport();
}
