// TASK 2: Create an interface ILogger with a method Log(string message).
