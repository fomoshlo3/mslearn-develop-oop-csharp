// TASK 4: Create an interface ILogger for logging messages
// Interface for logging messages.
public interface ILogger
{
    // Logs a message.
    void Log(string message);
}