// Interface for logging messages.
public interface ILogger
{
    // Logs a message.
    void Log(string message);
}